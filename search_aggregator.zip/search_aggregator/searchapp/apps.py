from django.apps import AppConfig


class SearchappConfig(AppConfig):
    name = 'searchapp'
